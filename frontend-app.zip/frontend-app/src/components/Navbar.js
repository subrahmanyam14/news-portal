import React, { useState, useEffect } from 'react';
import { Menu, X, LogIn, LayoutDashboard, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  // Check authentication status on component mount
  useEffect(() => {
    const checkAuthStatus = () => {
      const token = localStorage.getItem('token');
      setIsLoggedIn(!!token);
    };
  
    checkAuthStatus(); // Check initially
  
    window.addEventListener('storage', checkAuthStatus); // Listen for storage updates
  
    return () => {
      window.removeEventListener('storage', checkAuthStatus);
    };
  }, []);
  
  // Handle login navigation
  const handleLogin = () => {
    navigate('/login');
  };

  // Handle dashboard navigation
  const handleDashboard = () => {
    navigate('/dashboard');
  };

  // Handle home navigation
  const handleHome = () => {
    navigate('/');
  };

  // Handle logout
  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <header className="bg-[#dd163b] text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex flex-wrap items-center justify-between">
        <div className="flex items-center">
          <div 
            className="mr-4 text-3xl font-bold cursor-pointer"
            onClick={handleHome}
          >
            <span className="text-yellow-400">E-</span> 
            <span className="text-blue-300">Paper</span>
          </div>
          <div className="hidden md:block text-sm">
            <span className="mr-2">|</span>
            <span>A Portrait of Telangana People's Life</span>
          </div>
        </div>
        
        <div className="hidden md:flex items-center space-x-4">
          {/* Login/Dashboard/Logout Buttons */}
          {isLoggedIn ? (
            <div className="flex space-x-2">
              <button
                onClick={handleDashboard}
                className="flex items-center px-3 py-1 bg-green-600 rounded hover:bg-green-700"
              >
                <LayoutDashboard className="w-4 h-4 mr-1" />
                <span>Dashboard</span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center px-3 py-1 bg-red-600 rounded hover:bg-red-700"
              >
                <LogOut className="w-4 h-4 mr-1" />
                <span>Logout</span>
              </button>
            </div>
          ) : (
            <button
              onClick={handleLogin}
              className="flex items-center px-3 py-1 bg-yellow-500 rounded hover:bg-yellow-600"
            >
              <LogIn className="w-4 h-4 mr-1" />
              <span>Login</span>
            </button>
          )}
        </div>
        
        <button 
          className="md:hidden"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X /> : <Menu />}
        </button>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden px-4 py-3 bg-blue-800 flex flex-col space-y-3">
          {/* Mobile Login/Dashboard/Logout Buttons */}
          {isLoggedIn ? (
            <>
              <button
                onClick={handleDashboard}
                className="flex items-center px-3 py-1 bg-green-600 rounded hover:bg-green-700"
              >
                <LayoutDashboard className="w-4 h-4 mr-1" />
                <span>Dashboard</span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center px-3 py-1 bg-red-600 rounded hover:bg-red-700"
              >
                <LogOut className="w-4 h-4 mr-1" />
                <span>Logout</span>
              </button>
            </>
          ) : (
            <button
              onClick={handleLogin}
              className="flex items-center px-3 py-1 bg-yellow-500 rounded hover:bg-yellow-600"
            >
              <LogIn className="w-4 h-4 mr-1" />
              <span>Login</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};

export default Navbar;  